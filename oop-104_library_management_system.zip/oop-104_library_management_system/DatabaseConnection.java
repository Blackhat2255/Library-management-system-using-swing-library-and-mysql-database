import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/library_management";
    private static final String USER = "root"; // or your MySQL username
    private static final String PASSWORD = "root"; // or your MySQL password
    
    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC Driver not found", e);
        }
    }
    public static boolean verifyCredentials(String username, String password) {
    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement(
             "SELECT id FROM users WHERE username = ? AND password = ?")) {
        stmt.setString(1, username);
        stmt.setString(2, password);
        return stmt.executeQuery().next();
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}

public static boolean updateCredentials(String oldUsername, String newUsername, 
                                      String oldPassword, String newPassword) {
    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement(
             "UPDATE users SET username = ?, password = ? WHERE username = ? AND password = ?")) {
        
        stmt.setString(1, newUsername);
        stmt.setString(2, newPassword);
        stmt.setString(3, oldUsername);
        stmt.setString(4, oldPassword);
        
        return stmt.executeUpdate() > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
}
