import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Calendar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.*;
import java.sql.Statement;  // Add this at the top of your file'
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.time.temporal.ChronoUnit;
import java.time.Instant;
 






public class Source extends JFrame {
    private List<Book> bookList = new ArrayList<>();
    private int nextBookId = 1; // Auto-increment book ID

    private JTextField usernameField;
    private JPasswordField passwordField;
   

    // Professional color scheme
    private final Color PRIMARY_COLOR = new Color(44, 62, 80);    // Dark blue
    private final Color SECONDARY_COLOR = new Color(52, 152, 219); // Light blue
    private final Color ACCENT_COLOR = new Color(231, 76, 60);    // Red
    private final Color BACKGROUND_COLOR = new Color(240, 240, 245); // Light gray
    private final Color TEXT_COLOR = new Color(60, 60, 60);       // Dark gray

    public Source() {
        initializeUI();
        setupMainPanel();
        setupLoginPanel();
        initializeDatabase();
    }
    private void initializeUI() {
        setTitle("Library Management System");
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Fullscreen mode
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(800, 600));
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setupMainPanel() {
        JPanel mainPanel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                try {
                    // Load and draw background image
                    Image bgImage = new ImageIcon("C:\\Users\\ahmed\\OneDrive\\Desktop\\project\\resources\\pexels-suzyhazelwood-1629236.jpg").getImage();
                    g.drawImage(bgImage, 0, 0, getWidth(), getHeight(), this);
                    
                    // Add a semi-transparent overlay to make login panel more readable
                    g.setColor(new Color(52, 152, 219, 150)); // Blue with transparency
                    g.fillRect(0, 0, getWidth(), getHeight());
                } catch (Exception e) {
                    // Fallback to gradient if image fails to load
                    Graphics2D g2d = (Graphics2D) g;
                    g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                    GradientPaint gp = new GradientPaint(0, 0, new Color(52, 152, 219), 
                        getWidth(), getHeight(), new Color(41, 128, 185));
                    g2d.setPaint(gp);
                    g2d.fillRect(0, 0, getWidth(), getHeight());
                }
            }
        };
        add(mainPanel);
    }

    private void setupLoginPanel() {
        JPanel loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setBackground(Color.WHITE);
        loginPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0, 0, 0, 0.1f)),
            BorderFactory.createEmptyBorder(40, 40, 40, 40)
        ));
        loginPanel.setPreferredSize(new Dimension(450, 500));

        // Add shadow effect
        loginPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 1, 3, 3, new Color(0, 0, 0, 0.1f)),
            BorderFactory.createEmptyBorder(30, 30, 30, 30)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        // Application logo/icon
        JLabel iconLabel = new JLabel(new ImageIcon("library-icon.png")); // Add your own icon
        iconLabel.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        loginPanel.add(iconLabel, gbc);

        // Title
        JLabel titleLabel = new JLabel("LIBRARY LOGIN");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(PRIMARY_COLOR);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridy = 1;
        loginPanel.add(titleLabel, gbc);

        // Username field
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        loginPanel.add(usernameLabel, gbc);

        usernameField = new JTextField();
        styleTextField(usernameField);
        gbc.gridy = 3;
        loginPanel.add(usernameField, gbc);

        // Password field
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridy = 4;
        loginPanel.add(passwordLabel, gbc);

        passwordField = new JPasswordField();
        styleTextField(passwordField);
        gbc.gridy = 5;
        loginPanel.add(passwordField, gbc);

        JLabel roleLabel = new JLabel("Login As:");
        roleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridy = 6;
        loginPanel.add(roleLabel, gbc);

        JLabel librarianLabel = new JLabel("Librarian");
        librarianLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));                                                    
        gbc.gridy = 7;
        loginPanel.add(librarianLabel, gbc);

        // Login button - using the new professional button style
        JButton loginButton = createProfessionalButton("SIGN IN", SECONDARY_COLOR);
        
loginButton.addActionListener(e -> {
   String username = usernameField.getText().trim();
String password = new String(passwordField.getPassword()).trim();

    
    if (authenticateUser(username, password)) {
        dispose(); // Close login window
        new LibrarianDashboard(bookList, nextBookId).setVisible(true);
    } else {
        JOptionPane.showMessageDialog(this,
            "Invalid username or password",
            "Login Failed",
            JOptionPane.ERROR_MESSAGE);
            
    }
});
  
        gbc.gridy = 8;
        loginPanel.add(loginButton, gbc);

        // Add login panel to main panel
        ((JPanel)getContentPane().getComponent(0)).add(loginPanel);
    }

    JButton createProfessionalButton(String text, Color COLO) {
        JButton button = new JButton(text);
        
        // Base styling
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.blue);
        button.setBackground(COLO);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLO.darker(), 1),
            BorderFactory.createEmptyBorder(12, 30, 12, 30)
        ));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Hover effects
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(COLO.brighter());
                button.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(COLO.brighter().darker(), 1),
                    BorderFactory.createEmptyBorder(12, 30, 12, 30)
                ));
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(COLO);
                button.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(COLO.darker(), 1),
                    BorderFactory.createEmptyBorder(12, 30, 12, 30)
                ));
            }
            
            @Override
            public void mousePressed(MouseEvent e) {
                button.setBackground(COLO.darker());
            }
        });
        
        return button;
    }

    private void styleTextField(JTextField field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        field.setBackground(new Color(250, 250, 250));
    }

   

    private void initializeDatabase() {
    try (Connection conn = DatabaseConnection.getConnection();
         Statement stmt = conn.createStatement()) {
        
        // Create tables if not exists
        stmt.executeUpdate("CREATE TABLE IF NOT EXISTS fines (" +
            "id INT AUTO_INCREMENT PRIMARY KEY, " +
            "checkout_id INT NOT NULL, " +
            "amount DECIMAL(10,2) NOT NULL, " +
            "paid BOOLEAN DEFAULT false, " +
            "payment_date DATE, " +
            "FOREIGN KEY (checkout_id) REFERENCES checkouts(id))");

        stmt.executeUpdate("CREATE TABLE IF NOT EXISTS users (" +
            "id INT AUTO_INCREMENT PRIMARY KEY, " +
            "username VARCHAR(50) NOT NULL UNIQUE, " +
            "password VARCHAR(100) NOT NULL, " +
            "role VARCHAR(20) NOT NULL)");
        
        // Updated books table without quantity columns
        stmt.executeUpdate("CREATE TABLE IF NOT EXISTS books (" +
            "id INT AUTO_INCREMENT PRIMARY KEY, " +
            "title VARCHAR(100) NOT NULL, " +
            "author VARCHAR(100) NOT NULL, " +
            "isbn VARCHAR(20) NOT NULL, " +
            "status VARCHAR(20) NOT NULL DEFAULT 'Available')");  // Removed quantity fields
            
        stmt.executeUpdate("CREATE TABLE IF NOT EXISTS members (" +
            "id INT AUTO_INCREMENT PRIMARY KEY, " +
            "name VARCHAR(100) NOT NULL, " +
            "email VARCHAR(100) UNIQUE NOT NULL, " +
            "phone VARCHAR(20), " +
            "address VARCHAR(200), " +
            "active BOOLEAN DEFAULT true, " +
            "join_date DATE NOT NULL)");
        
        // Insert default admin if not exists
        ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM users WHERE username='admin'");
        rs.next();
        if (rs.getInt(1) == 0) {
            stmt.executeUpdate("INSERT INTO users (username, password, role) VALUES " +
                "('admin', 'admin123', 'librarian')");
        }
        
        // Load books from database
        loadBooksFromDB();
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, 
            "Database initialization failed: " + e.getMessage(),
            "Error", JOptionPane.ERROR_MESSAGE);
    }
}
    private void loadBooksFromDB() {
        bookList.clear();
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM books")) {
            
            while (rs.next()) {
                bookList.add(new Book(
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getString("author"),
                    rs.getString("isbn"),
                    rs.getString("status")
                ));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Failed to load books: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean authenticateUser(String username, String password) {
    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(
             "SELECT role FROM users WHERE username = ? AND password = ?")) {

        System.out.println("Authenticating: " + username + " / " + password); // DEBUG

        stmt.setString(1, username.trim());
        stmt.setString(2, password.trim());

        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            String role = rs.getString("role");
            System.out.println("User found. Role: " + role); // DEBUG

            if ("librarian".equalsIgnoreCase(role)) {
                return true;
            } else {
                System.out.println("Role is not librarian.");
            }
        } else {
            System.out.println("No matching user found.");
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
            "Database error: " + e.getMessage(),
            "Error", JOptionPane.ERROR_MESSAGE);
    }
    return false;
}


 
 public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Source frame = new Source();
            frame.setVisible(true);
        });
    }
}


// Book class should be outside LibrarianDashboard
 class Book {
    private int id;
    private String title;
    private String author;
    private String isbn;
    private String status;

    public Book(int id, String title, String author, String isbn, String status) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.status = status;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getStatus() {
        return status;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Optional: toString() method for easy printing
    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", isbn='" + isbn + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}





class LibrarianDashboard extends JFrame implements LibraryEventManager.LibraryEventListener {
    private List<Book> bookList;
    private int nextBookId;
    private JPanel mainPanel;
    private JPanel contentPanel;




private void showChangeCredentialsDialog() {
    JDialog dialog = new JDialog(this, "Change Credentials", true);
    dialog.setSize(450, 350);
    dialog.setLayout(new BorderLayout(10, 10));
    dialog.setLocationRelativeTo(this);

    // Main panel with form fields
    JPanel mainPanel = new JPanel(new GridBagLayout());
    mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
    
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(8, 8, 8, 8);
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.anchor = GridBagConstraints.WEST;
    gbc.gridx = 0;
    gbc.gridy = 0;

    // Create form components
    JTextField currentUserField = new JTextField(20);
    JPasswordField currentPassField = new JPasswordField(20);
    JTextField newUserField = new JTextField(20);
    JPasswordField newPassField = new JPasswordField(20);
    JPasswordField confirmPassField = new JPasswordField(20);

    // Add components to form
    addFormRow(mainPanel, gbc, "Current Username:", currentUserField);
    addFormRow(mainPanel, gbc, "Current Password:", currentPassField);
    addFormRow(mainPanel, gbc, "New Username:", newUserField);
    addFormRow(mainPanel, gbc, "New Password:", newPassField);
    addFormRow(mainPanel, gbc, "Confirm Password:", confirmPassField);

    // Button panel with both buttons
    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
    buttonPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 15));
    
    // Add Cancel button
    JButton cancelBtn = new JButton("Cancel");
    cancelBtn.addActionListener(e -> dialog.dispose());
    
    // Add Confirm/Change button
    JButton confirmBtn = new JButton("Confirm Changes");
    confirmBtn.addActionListener(e -> {
        String currentUser = currentUserField.getText().trim();
        String currentPass = new String(currentPassField.getPassword());
        String newUser = newUserField.getText().trim();
        String newPass = new String(newPassField.getPassword());
        String confirmPass = new String(confirmPassField.getPassword());

        // Validate inputs
        if (!validateInputs(currentUser, currentPass, newUser, newPass, confirmPass, dialog)) {
            return;
        }

        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            // Verify current credentials
            if (!verifyCredentials(conn, currentUser, currentPass)) {
                JOptionPane.showMessageDialog(dialog, 
                    "Invalid current credentials", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Check username availability
            if (!newUser.isEmpty() && !isUsernameAvailable(conn, newUser)) {
                JOptionPane.showMessageDialog(dialog,
                    "Username already exists",
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Update credentials
            if (updateCredentials(conn, currentUser, 
                               newUser.isEmpty() ? currentUser : newUser,
                               newPass.isEmpty() ? null : hashPassword(newPass))) {
                conn.commit();
                JOptionPane.showMessageDialog(dialog,
                    "Credentials updated successfully!",
                    "Success", JOptionPane.INFORMATION_MESSAGE);
                dialog.dispose();
            } else {
                conn.rollback();
                JOptionPane.showMessageDialog(dialog,
                    "Failed to update credentials",
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            try { if (conn != null) conn.rollback(); } catch (SQLException exp) {}
            JOptionPane.showMessageDialog(dialog,
                "Database error: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            try { if (conn != null) conn.setAutoCommit(true); } catch (SQLException exp) {}
            try { if (conn != null) conn.close(); } catch (SQLException exp) {}
        }
    });

    // Style buttons
    cancelBtn.setBackground(new Color(220, 220, 220));
    confirmBtn.setBackground(new Color(0, 120, 215));
    confirmBtn.setForeground(Color.WHITE);
    
    // Add buttons to panel
    buttonPanel.add(cancelBtn);
    buttonPanel.add(confirmBtn);

    // Add components to dialog
    dialog.add(mainPanel, BorderLayout.CENTER);
    dialog.add(buttonPanel, BorderLayout.SOUTH);
    dialog.setVisible(true);
}

// Helper method to add form rows
private void addFormRow(JPanel panel, GridBagConstraints gbc, String label, JComponent field) {
    gbc.gridx = 0;
    panel.add(new JLabel(label), gbc);
    gbc.gridx = 1;
    panel.add(field, gbc);
    gbc.gridy++;
}


private boolean validateInputs(String currentUser, String currentPass, 
                             String newUser, String newPass, 
                             String confirmPass, JDialog parent) {
    // Validate current credentials are provided
    if (currentUser.isEmpty()) {
        JOptionPane.showMessageDialog(parent, 
            "Current username cannot be empty",
            "Validation Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }

    if (currentPass.isEmpty()) {
        JOptionPane.showMessageDialog(parent, 
            "Current password cannot be empty",
            "Validation Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }

    // Validate at least one change is being made
    if (newUser.isEmpty() && newPass.isEmpty()) {
        JOptionPane.showMessageDialog(parent, 
            "You must provide either a new username or new password",
            "Validation Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }

    // Validate new username if provided
    if (!newUser.isEmpty()) {
        if (newUser.length() < 4) {
            JOptionPane.showMessageDialog(parent, 
                "Username must be at least 4 characters long",
                "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (newUser.equals(currentUser)) {
            JOptionPane.showMessageDialog(parent, 
                "New username cannot be same as current username",
                "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    // Validate new password if provided
    if (!newPass.isEmpty()) {
        // Only check that password isn't empty and matches confirmation
        if (newPass.length() == 0) {
            JOptionPane.showMessageDialog(parent, 
                "New password cannot be empty",
                "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!newPass.equals(confirmPass)) {
            JOptionPane.showMessageDialog(parent, 
                "New password and confirmation do not match",
                "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    // All validations passed
    return true;
}

// Helper methods:

private boolean verifyCredentials(Connection conn, String username, String password) 
    throws SQLException {
    try (PreparedStatement stmt = conn.prepareStatement(
        "SELECT password FROM users WHERE username = ?")) {
        stmt.setString(1, username);
        ResultSet rs = stmt.executeQuery();
        return rs.next() && verifyPassword(password, rs.getString("password"));
    }
}

private boolean isUsernameAvailable(Connection conn, String username) throws SQLException {
    try (PreparedStatement stmt = conn.prepareStatement(
        "SELECT 1 FROM users WHERE username = ?")) {
        stmt.setString(1, username);
        return !stmt.executeQuery().next();
    }
}

private boolean updateCredentials(Connection conn, String oldUsername, 
                                   String newUsername, String newPassword) 
    throws SQLException {
    // 1. First delete old credentials to invalidate them
    try (PreparedStatement deleteStmt = conn.prepareStatement(
        "DELETE FROM users WHERE username = ?")) {
        deleteStmt.setString(1, oldUsername);
        deleteStmt.executeUpdate();
    }

    // 2. Insert new credentials
    try (PreparedStatement insertStmt = conn.prepareStatement(
        "INSERT INTO users (username, password) VALUES (?, ?)")) {
        insertStmt.setString(1, newUsername);
        insertStmt.setString(2, newPassword == null ? 
            getCurrentHashedPassword(conn, oldUsername) : hashPassword(newPassword));
        return insertStmt.executeUpdate() > 0;
    }
}

private String getCurrentHashedPassword(Connection conn, String username) throws SQLException {
    try (PreparedStatement stmt = conn.prepareStatement(
        "SELECT password FROM users WHERE username = ?")) {
        stmt.setString(1, username);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            return rs.getString("password");
        }
        throw new SQLException("Current user not found");
    }
}

// Password security - IMPLEMENT PROPERLY in production
private String hashPassword(String password) {
    // In production, use: return BCrypt.hashpw(password, BCrypt.gensalt());
    return password; // placeholder - INSECURE for production!
}

private boolean verifyPassword(String inputPassword, String storedHash) {
    // In production, use: return BCrypt.checkpw(inputPassword, storedHash);
    return hashPassword(inputPassword).equals(storedHash); // placeholder
}



    private DashboardStats fetchDashboardStatistics() {
    try (Connection conn = DatabaseConnection.getConnection()) {
        int totalBooks = getCount(conn, "SELECT COUNT(*) FROM books");
        int availableBooks = getCount(conn, "SELECT COUNT(*) FROM books WHERE status = 'Available'");
        int checkedOutBooks = getCount(conn, "SELECT COUNT(*) FROM books WHERE status = 'Checked Out'");
        int overdueBooks = getCount(conn, "SELECT COUNT(*) FROM checkouts WHERE due_date < CURRENT_DATE AND returned = false");
        int activeMembers = getCount(conn, "SELECT COUNT(*) FROM members WHERE active = true");
        int pendingReturns = getCount(conn, "SELECT COUNT(*) FROM checkouts WHERE returned = false");
        
        return new DashboardStats(totalBooks, availableBooks, checkedOutBooks, 
                                overdueBooks, activeMembers, pendingReturns);
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, 
            "Error loading dashboard statistics: " + e.getMessage(),
            "Database Error", JOptionPane.ERROR_MESSAGE);
        return new DashboardStats(0, 0, 0, 0, 0, 0);
    }
}

private int getCount(Connection conn, String query) throws SQLException {
    try (PreparedStatement stmt = conn.prepareStatement(query);
         ResultSet rs = stmt.executeQuery()) {
        return rs.next() ? rs.getInt(1) : 0;
    }
}

private JPanel createStatCard(String title, int value, Color color) {
    JPanel card = new JPanel(new BorderLayout());
    card.setBackground(Color.WHITE);
    card.setBorder(BorderFactory.createCompoundBorder(
        BorderFactory.createMatteBorder(0, 0, 3, 3, new Color(0, 0, 0, 0.1f)),
        BorderFactory.createEmptyBorder(25, 25, 25, 25)
    ));

    JLabel titleLabel = new JLabel(title);
    titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
    titleLabel.setForeground(new Color(80, 80, 80));

    JLabel valueLabel = new JLabel(String.valueOf(value));
    valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 36));
    valueLabel.setForeground(color);
    valueLabel.setHorizontalAlignment(SwingConstants.CENTER);

    card.add(titleLabel, BorderLayout.NORTH);
    card.add(valueLabel, BorderLayout.CENTER);
    return card;
}
    @Override
    public void onLibraryDataChanged(){
        if (contentPanel != null && contentPanel.getComponentCount() > 0) {
          showDashboard(); // Refresh the dashboard view
     }
    }

    JButton createProfessionalButton(String text, Color COLO) {
        JButton button = new JButton(text);
        
        // Base styling
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.blue);
        button.setBackground(COLO);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLO.darker(), 1),
            BorderFactory.createEmptyBorder(12, 30, 12, 30)
        ));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Hover effects
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(COLO.brighter());
                button.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(COLO.brighter().darker(), 1),
                    BorderFactory.createEmptyBorder(12, 30, 12, 30)
                ));
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(COLO);
                button.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(COLO.darker(), 1),
                    BorderFactory.createEmptyBorder(12, 30, 12, 30)
                ));
            }
            
            @Override
            public void mousePressed(MouseEvent e) {
                button.setBackground(COLO.darker());
            }

           
    
        });
     
        
        return button;
    }

    
    public LibrarianDashboard(List<Book> bookList, int nextBookId) {
        this.bookList = bookList;
        this.nextBookId = nextBookId;
        
        
        setTitle("Library Management System - Librarian Dashboard");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     
        JButton changeCredentialsBtn = new JButton("Change Credentials");
        changeCredentialsBtn.addActionListener(e -> showChangeCredentialsDialog());
        // Add this button to your UI wherever appropriate

    
   



        
        // Main panel with BorderLayout
        mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(245, 248, 250));

        // ================= SIDEBAR =================
        JPanel sidebar = createSidebar();
        mainPanel.add(sidebar, BorderLayout.WEST);

        // ================= MAIN CONTENT =================
        contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(new Color(245, 248, 250));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        mainPanel.add(contentPanel, BorderLayout.CENTER);
        add(mainPanel);
        
        // Show dashboard by default
        showDashboard();
        LibraryEventManager.addListener(this);
    }

    private JPanel createSidebar() {
    JPanel sidebar = new JPanel();
    sidebar.setBackground(new Color(34, 49, 63));
    sidebar.setLayout(new GridLayout(7, 1, 0, 10)); // Increased rows to accommodate the new button
    sidebar.setPreferredSize(new Dimension(280, getHeight()));
    sidebar.setBorder(BorderFactory.createEmptyBorder(25, 0, 25, 0));

    Color[] buttonColors = {
        new Color(0, 123, 255),   // Dashboard - Blue
        new Color(40, 167, 69),   // Manage Books - Green
        new Color(255, 193, 7),   // Issue Book - Yellow
        new Color(255, 87, 34),   // Return Book - Red
        new Color(156, 39, 176),  // Member Records - Purple
        new Color(108, 117, 125), // Change Credentials - Gray
        new Color(220, 53, 69)    // Logout - Danger
    };

    String[] btnNames = {
        "Dashboard", "Manage Books", "Issue Book",
        "Return Book", "Member Records", "Change Credentials", "Logout"
    };
    String[] iconCodes = {
        "📊", "📚", "🎫", "🔄", "👥", "🔐", "🚪"
    };

    for (int i = 0; i < btnNames.length; i++) {
        final int buttonIndex = i;
        JButton btn = new JButton();
        btn.setText("<html><div style='text-align:left;padding-left:10px;'>" 
                  + "<span style='font-size:20px;'>" + iconCodes[i] + "</span>"
                  + "<span style='font-size:16px;margin-left:15px;'>" + btnNames[i] + "</span>"
                  + "</div></html>");

        // Button styling
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setForeground(Color.WHITE);
        btn.setBackground(buttonColors[buttonIndex]);
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(true);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(15, 25, 15, 25));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Hover effects
        btn.addMouseListener(new MouseAdapter() {
            Color originalColor = buttonColors[buttonIndex];

            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(originalColor.brighter());
                btn.setBorder(BorderFactory.createMatteBorder(0, 3, 0, 0, originalColor.brighter()));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(originalColor);
                btn.setBorder(BorderFactory.createEmptyBorder(15, 25, 15, 25));
            }

            @Override
            public void mousePressed(MouseEvent e) {
                btn.setBackground(originalColor.darker());
            }
        });

        // Add action listeners for each button
        switch (btnNames[i]) {
            case "Dashboard":
                btn.addActionListener(e -> showDashboard());
                break;
            case "Manage Books":
                btn.addActionListener(e -> showManageBooks());
                break;
            case "Issue Book":
                btn.addActionListener(e -> showIssueBook());
                break;
            case "Return Book":
                btn.addActionListener(e -> showReturnBook());
                break;
            case "Member Records":
                btn.addActionListener(e -> showMemberRecords());
                break;
            case "Change Credentials":
                btn.addActionListener(e -> showChangeCredentialsDialog());
                break;
            case "Logout":
                btn.addActionListener(e -> {
                    dispose();
                    new Source().setVisible(true);
                });
                break;
        }

        sidebar.add(btn);
    }

    return sidebar;
}

    





    private void showDashboard() {
    contentPanel.removeAll();
    
    // Header with welcome message
    JPanel headerPanel = createDashboardHeader();
    contentPanel.add(headerPanel, BorderLayout.NORTH);

    // Stats cards
    JPanel statsPanel = new JPanel(new GridLayout(2, 3, 25, 25));
    statsPanel.setBackground(new Color(245, 248, 250));

    String[] statsTitles = {"Total Books", "Available Books", "Books Checked Out", 
                           "Overdue Books", "Active Members", "Pending Returns"};
    Color[] cardColors = {
        new Color(52, 152, 219), // Blue
        new Color(46, 204, 113), // Green
        new Color(155, 89, 182), // Purple
        new Color(231, 76, 60),  // Red
        new Color(241, 196, 15), // Yellow
        new Color(230, 126, 34)  // Orange
    };

    // Create cards with real-time data
    DashboardStats stats = fetchDashboardStatistics();
    for (int i = 0; i < statsTitles.length; i++) {
        statsPanel.add(createStatCard(statsTitles[i], stats.getValue(i), cardColors[i]));
    }

    contentPanel.add(statsPanel, BorderLayout.CENTER);
    
    // Add refresh button
    JButton refreshButton = createProfessionalButton("Refresh Dashboard", new Color(52, 152, 219));
    refreshButton.addActionListener(e -> showDashboard());
    
    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    buttonPanel.setBackground(new Color(245, 248, 250));
    buttonPanel.add(refreshButton);
    contentPanel.add(buttonPanel, BorderLayout.SOUTH);
    
    contentPanel.revalidate();
    contentPanel.repaint();
}

private JPanel createDashboardHeader() {
    JPanel headerPanel = new JPanel(new BorderLayout());
    headerPanel.setBackground(new Color(245, 248, 250));
    headerPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 30, 0));

    JLabel welcomeLabel = new JLabel("Welcome, Librarian!");
    welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
    welcomeLabel.setForeground(new Color(44, 62, 80));
    welcomeLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

    JLabel dateLabel = new JLabel("Today is " + new SimpleDateFormat("EEEE, MMMM d, yyyy").format(new Date()));
    dateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
    dateLabel.setForeground(new Color(120, 120, 120));

    headerPanel.add(welcomeLabel, BorderLayout.NORTH);
    headerPanel.add(dateLabel, BorderLayout.SOUTH);
    
    return headerPanel;
}


 // Enhanced createProfessionalButton method with better visibility
private void showManageBooks() {
    contentPanel.removeAll();
    contentPanel.setLayout(new BorderLayout());

    JPanel bookManagementPanel = new JPanel(new BorderLayout());
    bookManagementPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

    // Search Panel (unchanged)
    JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
    searchPanel.setBackground(new Color(245, 248, 250));
    searchPanel.setBorder(BorderFactory.createTitledBorder("Search Books"));

    JTextField searchField = new JTextField(25);
    searchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    searchField.setBorder(BorderFactory.createCompoundBorder(
        BorderFactory.createLoweredBevelBorder(),
        BorderFactory.createEmptyBorder(5, 5, 5, 5)
    ));

    JButton searchButton = createProfessionalButton(" Search", new Color(0, 123, 255));
    JButton clearButton = createProfessionalButton(" Clear", new Color(108, 117, 125));

    searchButton.setPreferredSize(new Dimension(120, 40));
    clearButton.setPreferredSize(new Dimension(100, 40));

    searchPanel.add(new JLabel("Search by Title/Author: "));
    searchPanel.add(searchField);
    searchPanel.add(Box.createHorizontalStrut(10));
    searchPanel.add(searchButton);
    searchPanel.add(clearButton);

    // Updated Table Model (removed quantity columns)
    DefaultTableModel tableModel = new DefaultTableModel(
        new Object[]{"ID", "Title", "Author", "ISBN", "Status"}, 0) {
        @Override
        public Class<?> getColumnClass(int columnIndex) {
            if (columnIndex == 0) return Integer.class;
            return String.class;
        }

        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    JTable booksTable = new JTable(tableModel);
    booksTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    booksTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
    booksTable.getTableHeader().setBackground(new Color(233, 236, 239));
    booksTable.setRowHeight(35);
    booksTable.setShowGrid(true);
    booksTable.setGridColor(new Color(222, 226, 230));
    booksTable.setSelectionBackground(new Color(0, 123, 255, 50));

    // Simplified cell renderer
    DefaultTableCellRenderer leftRenderer = new DefaultTableCellRenderer();
    leftRenderer.setHorizontalAlignment(SwingConstants.LEFT);
    booksTable.getColumnModel().getColumn(0).setCellRenderer(leftRenderer); // ID

    JScrollPane scrollPane = new JScrollPane(booksTable);
    scrollPane.setBorder(BorderFactory.createTitledBorder("Books List"));

    // Action Panel (unchanged)
    JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
    actionPanel.setBackground(new Color(245, 248, 250));
    actionPanel.setBorder(BorderFactory.createTitledBorder("Actions"));

    JButton addButton = createProfessionalButton(" Add New Book", new Color(40, 180, 99));
    JButton refreshButton = createProfessionalButton("Refresh", new Color(255, 193, 7));
    JButton editButton = createProfessionalButton("Edit Selected", new Color(52, 152, 219));
    JButton deleteButton = createProfessionalButton("Delete Selected", new Color(231, 76, 60));

    Dimension buttonSize = new Dimension(160, 40);
    addButton.setPreferredSize(new Dimension(180, 40));
    refreshButton.setPreferredSize(new Dimension(120, 40));
    editButton.setPreferredSize(buttonSize);
    deleteButton.setPreferredSize(new Dimension(180, 40));

    actionPanel.add(refreshButton);
    actionPanel.add(editButton);
    actionPanel.add(deleteButton);
    actionPanel.add(addButton);
    
    // Combine panels
    bookManagementPanel.add(searchPanel, BorderLayout.NORTH);
    bookManagementPanel.add(scrollPane, BorderLayout.CENTER);
    bookManagementPanel.add(actionPanel, BorderLayout.SOUTH);
    contentPanel.add(bookManagementPanel, BorderLayout.CENTER);

    // Updated loadTable without quantity logic
    Runnable loadTable = () -> {
        tableModel.setRowCount(0);
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                 "SELECT b.id, b.title, b.author, b.isbn, b.status " +
                 "FROM books b")) {

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getString("author"),
                    rs.getString("isbn"),
                    rs.getString("status")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, 
                "Error loading books:\n" + e.getMessage(), 
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    };

    // Updated search without quantity logic
    searchButton.addActionListener(e -> {
        String keyword = searchField.getText().trim().toLowerCase();
        if (keyword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a search term.", "Search", JOptionPane.WARNING_MESSAGE);
            return;
        }

        tableModel.setRowCount(0);
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "SELECT b.id, b.title, b.author, b.isbn, b.status " +
                 "FROM books b " +
                 "WHERE LOWER(b.title) LIKE ? OR LOWER(b.author) LIKE ? OR LOWER(b.isbn) LIKE ?")) {

            String query = "%" + keyword.toLowerCase() + "%";
            stmt.setString(1, query);
            stmt.setString(2, query);
            stmt.setString(3, query);

            ResultSet rs = stmt.executeQuery();
            int count = 0;

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getString("author"),
                    rs.getString("isbn"),
                    rs.getString("status")
                });
                count++;
            }

            if (count == 0) {
                JOptionPane.showMessageDialog(this,
                    "No books found for: '" + keyword + "'",
                    "Search Result", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                "Search failed:\n" + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    });

    // Clear (unchanged)
    clearButton.addActionListener(e -> {
        searchField.setText("");
        loadTable.run();
    });

    // Refresh (unchanged)
    refreshButton.addActionListener(e -> {
        loadTable.run();
        JOptionPane.showMessageDialog(this, "Book list refreshed!", "Refresh", JOptionPane.INFORMATION_MESSAGE);
    });

    // Updated edit without quantity
    editButton.addActionListener(e -> {
        int selectedRow = booksTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Select a book to edit.", "Edit Book", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int bookId = (Integer) tableModel.getValueAt(selectedRow, 0);
        String title = (String) tableModel.getValueAt(selectedRow, 1);
        String author = (String) tableModel.getValueAt(selectedRow, 2);
        String isbn = (String) tableModel.getValueAt(selectedRow, 3);
        String status = (String) tableModel.getValueAt(selectedRow, 4);

        showEditBookDialog(bookId, title, author, isbn, status, loadTable);
    });

    // Add (unchanged)
    addButton.addActionListener(e -> showAddBookDialog(loadTable));

    // Updated delete without quantity checks
    deleteButton.addActionListener(e -> {
        int selectedRow = booksTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Select a book to delete.", "Delete Book", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int bookId = (Integer) tableModel.getValueAt(selectedRow, 0);
        String title = (String) tableModel.getValueAt(selectedRow, 1);

        // Check if book is checked out
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "SELECT COUNT(*) FROM checkouts " +
                 "WHERE book_id = ? AND returned = false")) {
            
            stmt.setInt(1, bookId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(this, 
                    "Cannot delete book with active checkouts", 
                    "Delete Book", JOptionPane.WARNING_MESSAGE);
                return;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, 
                "Error checking checkouts: " + ex.getMessage(), 
                "Database Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete: " + title + "?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(
                         "DELETE FROM books WHERE id = ?")) {
                
                stmt.setInt(1, bookId);
                int rows = stmt.executeUpdate();
                
                if (rows > 0) {
                    loadTable.run();
                    JOptionPane.showMessageDialog(this, 
                        "Book deleted successfully!", 
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                    LibraryEventManager.notifyDataChanged();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, 
                    "Delete failed:\n" + ex.getMessage(), 
                    "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    });

    contentPanel.revalidate();
    contentPanel.repaint();
    loadTable.run();   // Initial load
}


// FIXED: Edit dialog with corrected column handling
private void showEditBookDialog(int bookId, String currentTitle, String currentAuthor,
                              String currentIsbn, String currentStatus,
                              Runnable refreshCallback) {

    JDialog editDialog = new JDialog(this, "Edit Book", true);
    editDialog.setSize(500, 400); // Reduced height since we removed quantity
    editDialog.setLocationRelativeTo(this);
    editDialog.setLayout(new BorderLayout());

    JPanel formPanel = new JPanel(new GridBagLayout());
    formPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 20, 30));
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);

    // Style font
    Font fieldFont = new Font("Segoe UI", Font.PLAIN, 14);

    // Create form fields with current values
    JTextField titleField = new JTextField(currentTitle, 20);
    titleField.setFont(fieldFont);

    JTextField authorField = new JTextField(currentAuthor, 20);
    authorField.setFont(fieldFont);

    JTextField isbnField = new JTextField(currentIsbn, 20);
    isbnField.setFont(fieldFont);

    // Add components to form
    gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.EAST;
    formPanel.add(new JLabel("Title: "), gbc);
    gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
    formPanel.add(titleField, gbc);

    gbc.gridx = 0; gbc.gridy = 1; gbc.anchor = GridBagConstraints.EAST;
    formPanel.add(new JLabel("Author: "), gbc);
    gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
    formPanel.add(authorField, gbc);

    gbc.gridx = 0; gbc.gridy = 2; gbc.anchor = GridBagConstraints.EAST;
    formPanel.add(new JLabel("ISBN: "), gbc);
    gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
    formPanel.add(isbnField, gbc);

    // Show current status as info label (read-only)
    gbc.gridx = 0; gbc.gridy = 3; gbc.anchor = GridBagConstraints.EAST;
    formPanel.add(new JLabel("Current Status: "), gbc);
    gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
    JLabel statusLabel = new JLabel(currentStatus);
    statusLabel.setFont(fieldFont);
    statusLabel.setForeground(currentStatus.equals("Available") ? 
        new Color(46, 204, 113) : new Color(231, 76, 60));
    formPanel.add(statusLabel, gbc);

    // Buttons
    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
    buttonPanel.setBackground(new Color(248, 249, 250));

    JButton saveButton = createProfessionalButton("Save Changes", new Color(40, 180, 99));
    JButton cancelButton = createProfessionalButton("Cancel", new Color(231, 76, 60));
    saveButton.setPreferredSize(new Dimension(180, 35));
    cancelButton.setPreferredSize(new Dimension(150, 35));

    buttonPanel.add(cancelButton);
    buttonPanel.add(saveButton);

    editDialog.add(formPanel, BorderLayout.CENTER);
    editDialog.add(buttonPanel, BorderLayout.SOUTH);

    // Cancel Action
    cancelButton.addActionListener(e -> editDialog.dispose());

    // Save Action
    saveButton.addActionListener(e -> {
        String newTitle = titleField.getText().trim();
        String newAuthor = authorField.getText().trim();
        String newIsbn = isbnField.getText().trim();

        if (newTitle.isEmpty() || newAuthor.isEmpty() || newIsbn.isEmpty()) {
            JOptionPane.showMessageDialog(editDialog,
                "Please fill all required fields:\n• Title\n• Author\n• ISBN",
                "Missing Information", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Check for duplicate ISBN
        if (!newIsbn.equals(currentIsbn)) {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(
                     "SELECT COUNT(*) FROM books WHERE isbn = ? AND id != ?")) {

                stmt.setString(1, newIsbn);
                stmt.setInt(2, bookId);
                ResultSet rs = stmt.executeQuery();

                if (rs.next() && rs.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(editDialog,
                        "A book with this ISBN already exists!",
                        "Duplicate ISBN", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(editDialog,
                    "Error checking ISBN: " + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // Perform Update (without quantity)
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "UPDATE books SET title = ?, author = ?, isbn = ? WHERE id = ?")) {

            stmt.setString(1, newTitle);
            stmt.setString(2, newAuthor);
            stmt.setString(3, newIsbn);
            stmt.setInt(4, bookId);

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(editDialog, 
                    "Book updated successfully!", 
                    "Success", JOptionPane.INFORMATION_MESSAGE);
                editDialog.dispose();
                refreshCallback.run();
                LibraryEventManager.notifyDataChanged();
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(editDialog,
                "Update failed:\n" + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    });

    editDialog.setVisible(true);
}


private void showAddBookDialog(Runnable refreshCallback) {
    JDialog addDialog = new JDialog(this, "Add New Book", true);
    addDialog.setSize(500, 350); // Reduced height since we removed quantity
    addDialog.setLocationRelativeTo(this);
    addDialog.setLayout(new BorderLayout());

    JPanel formPanel = new JPanel(new GridBagLayout());
    formPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 20, 30));
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);

    // Create form fields
    JTextField titleField = new JTextField(20);
    JTextField authorField = new JTextField(20);
    JTextField isbnField = new JTextField(20);
    
    // Style the form fields
    Font fieldFont = new Font("Segoe UI", Font.PLAIN, 14);
    titleField.setFont(fieldFont);
    authorField.setFont(fieldFont);
    isbnField.setFont(fieldFont);

    // Add components to form
    gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.EAST;
    formPanel.add(new JLabel("Title: "), gbc);
    gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
    formPanel.add(titleField, gbc);

    gbc.gridx = 0; gbc.gridy = 1; gbc.anchor = GridBagConstraints.EAST;
    formPanel.add(new JLabel("Author: "), gbc);
    gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
    formPanel.add(authorField, gbc);

    gbc.gridx = 0; gbc.gridy = 2; gbc.anchor = GridBagConstraints.EAST;
    formPanel.add(new JLabel("ISBN: "), gbc);
    gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
    formPanel.add(isbnField, gbc);

    // Button panel
    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
    buttonPanel.setBackground(new Color(248, 249, 250));
    
    JButton saveButton = createProfessionalButton("Save Book", new Color(40, 180, 99));
    JButton cancelButton = createProfessionalButton(" Cancel", new Color(231, 76, 60));
    
    saveButton.setPreferredSize(new Dimension(160, 35));
    cancelButton.setPreferredSize(new Dimension(130, 35));

    buttonPanel.add(cancelButton);
    buttonPanel.add(saveButton);

    addDialog.add(formPanel, BorderLayout.CENTER);
    addDialog.add(buttonPanel, BorderLayout.SOUTH);

    // Save functionality
    saveButton.addActionListener(e -> {
        String title = titleField.getText().trim();
        String author = authorField.getText().trim();
        String isbn = isbnField.getText().trim();

        if (title.isEmpty() || author.isEmpty() || isbn.isEmpty()) {
            JOptionPane.showMessageDialog(addDialog, 
                "Please fill all required fields:\n• Title\n• Author\n• ISBN", 
                "Missing Information", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Check for duplicate ISBN
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "SELECT COUNT(*) FROM books WHERE isbn = ?")) {
            
            stmt.setString(1, isbn);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next() && rs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(addDialog, 
                    "A book with this ISBN already exists!", 
                    "Duplicate ISBN", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(addDialog,
                "Error checking ISBN: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "INSERT INTO books (title, author, isbn, status) VALUES (?, ?, ?, 'Available')",
                 Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, title);
            stmt.setString(2, author);
            stmt.setString(3, isbn);
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                LibraryEventManager.notifyDataChanged();
                refreshCallback.run();
                ResultSet generatedKeys = stmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    JOptionPane.showMessageDialog(addDialog, 
                        "Book added successfully!\n\nTitle: " + title + 
                        "\nAuthor: " + author, 
                        "Success", 
                        JOptionPane.INFORMATION_MESSAGE);
                    addDialog.dispose();
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(addDialog,
                "Error saving book: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    });

    cancelButton.addActionListener(b -> addDialog.dispose());
    addDialog.setVisible(true);
}

   private void showIssueBook() {
    contentPanel.removeAll();
    contentPanel.setLayout(new BorderLayout());

    JPanel issuePanel = new JPanel(new GridBagLayout());
    issuePanel.setBackground(new Color(245, 248, 250));
    issuePanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(15, 15, 15, 15);
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.weightx = 1.0;

    // Title
    JLabel titleLabel = new JLabel("Issue Book to Member");
    titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
    titleLabel.setForeground(new Color(44, 62, 80));
    titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 2;
    issuePanel.add(titleLabel, gbc);

    // Book ID
    JLabel bookIdLabel = new JLabel("Book ID:");
    bookIdLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    gbc.gridy = 1;
    gbc.gridwidth = 1;
    issuePanel.add(bookIdLabel, gbc);

    JTextField bookIdField = new JTextField();
    styleTextField(bookIdField);
    gbc.gridx = 1;
    issuePanel.add(bookIdField, gbc);

    // Member ID
    JLabel memberIdLabel = new JLabel("Member ID:");
    memberIdLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    gbc.gridx = 0;
    gbc.gridy = 2;
    issuePanel.add(memberIdLabel, gbc);

    JTextField memberIdField = new JTextField();
    styleTextField(memberIdField);
    gbc.gridx = 1;
    issuePanel.add(memberIdField, gbc);

    // Issue Date (today)
    JLabel issueDateLabel = new JLabel("Issue Date:");
    issueDateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    gbc.gridx = 0;
    gbc.gridy = 3;
    issuePanel.add(issueDateLabel, gbc);

    JTextField issueDateField = new JTextField(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
    styleTextField(issueDateField);
    issueDateField.setEditable(false);
    gbc.gridx = 1;
    issuePanel.add(issueDateField, gbc);

    // Due Date (14 days later)
    JLabel dueDateLabel = new JLabel("Due Date:");
    dueDateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    gbc.gridx = 0;
    gbc.gridy = 4;
    issuePanel.add(dueDateLabel, gbc);

    Calendar cal = Calendar.getInstance();
    cal.add(Calendar.DATE, 14);
    JTextField dueDateField = new JTextField(new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime()));
    styleTextField(dueDateField);
    gbc.gridx = 1;
    issuePanel.add(dueDateField, gbc);

    // Issue Button
    JButton issueButton = createProfessionalButton("Issue Book", new Color(52, 152, 219));
    issueButton.setPreferredSize(new Dimension(150, 40));
    gbc.gridx = 0;
    gbc.gridy = 5;
    gbc.gridwidth = 2;
    gbc.anchor = GridBagConstraints.CENTER;
    issuePanel.add(issueButton, gbc);

    // Lookup Buttons Panel
    JPanel lookupPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
    JButton lookupBookButton = createProfessionalButton("Lookup Book", new Color(108, 117, 125));
    JButton lookupMemberButton = createProfessionalButton("Lookup Member", new Color(108, 117, 125));
    lookupBookButton.setPreferredSize(new Dimension(180, 30));
    lookupMemberButton.setPreferredSize(new Dimension(180, 30));
    lookupPanel.add(lookupBookButton);
    lookupPanel.add(lookupMemberButton);
    gbc.gridy = 6;
    issuePanel.add(lookupPanel, gbc);

    // Lookup Book action - updated to check status
    lookupBookButton.addActionListener(e -> {
        String bookId = bookIdField.getText().trim();
        if (bookId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a Book ID", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "SELECT b.title, b.status FROM books b WHERE b.id = ?")) {
            
            int bookIdInt = Integer.parseInt(bookId);
            stmt.setInt(1, bookIdInt);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                String title = rs.getString("title");
                String status = rs.getString("status");
                
                if ("Available".equals(status)) {
                    JOptionPane.showMessageDialog(this, 
                        "Book is available: " + title, 
                        "Book Available", 
                        JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "Book is currently checked out: " + title, 
                        "Unavailable", 
                        JOptionPane.WARNING_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, 
                    "No book found with ID: " + bookId, 
                    "Not Found", 
                    JOptionPane.WARNING_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, 
                "Please enter a valid numeric Book ID", 
                "Input Error", 
                JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, 
                "Database error: " + ex.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    });

    // Lookup Member action (unchanged)
    lookupMemberButton.addActionListener(e -> {
        String memberId = memberIdField.getText().trim();
        if (memberId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a Member ID", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM members WHERE id = ?")) {
            stmt.setInt(1, Integer.parseInt(memberId));
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String name = rs.getString("name");
                JOptionPane.showMessageDialog(this, "Member found: " + name, "Member Found", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "No member found with ID: " + memberId, "Not Found", JOptionPane.WARNING_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid numeric Member ID", "Input Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    });

    // Issue Book action - updated with status checks
    issueButton.addActionListener(e -> {
    // Input validation
    String bookIdStr = bookIdField.getText().trim();
    String memberIdStr = memberIdField.getText().trim();
    
    if (bookIdStr.isEmpty() || memberIdStr.isEmpty()) {
        JOptionPane.showMessageDialog(this, 
            "Please enter both Book ID and Member ID", 
            "Input Error", JOptionPane.WARNING_MESSAGE);
        return;
    }

    Connection conn = null;
    try {
        // Parse inputs
        int bookId = Integer.parseInt(bookIdStr);
        int memberId = Integer.parseInt(memberIdStr);
        Date issueDate = new Date(); // Current date
        Date dueDate = new SimpleDateFormat("yyyy-MM-dd").parse(dueDateField.getText());

        conn = DatabaseConnection.getConnection();
        conn.setAutoCommit(false);

        // 1. Verify book exists and is available
        try (PreparedStatement stmt = conn.prepareStatement(
                "SELECT title, status FROM books WHERE id = ? FOR UPDATE")) {
            stmt.setInt(1, bookId);
            ResultSet rs = stmt.executeQuery();
            
            if (!rs.next()) {
                JOptionPane.showMessageDialog(this, 
                    "Book not found with ID: " + bookId, 
                    "Error", JOptionPane.WARNING_MESSAGE);
                conn.rollback();
                return;
            }
            
            String status = rs.getString("status");
            if (!"Available".equals(status)) {
                JOptionPane.showMessageDialog(this, 
                    "Book '" + rs.getString("title") + "' is currently " + status, 
                    "Unavailable", JOptionPane.WARNING_MESSAGE);
                conn.rollback();
                return;
            }
        }

        // 2. Verify member exists and is active
        try (PreparedStatement stmt = conn.prepareStatement(
                "SELECT name, active FROM members WHERE id = ?")) {
            stmt.setInt(1, memberId);
            ResultSet rs = stmt.executeQuery();
            
            if (!rs.next()) {
                JOptionPane.showMessageDialog(this, 
                    "Member not found with ID: " + memberId, 
                    "Error", JOptionPane.WARNING_MESSAGE);
                conn.rollback();
                return;
            }
            
            if (!rs.getBoolean("active")) {
                JOptionPane.showMessageDialog(this, 
                    "Member '" + rs.getString("name") + "' account is inactive", 
                    "Error", JOptionPane.WARNING_MESSAGE);
                conn.rollback();
                return;
            }
        }

        // 3. Create checkout record
        try (PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO checkouts (book_id, member_id, checkout_date, due_date) " +
                "VALUES (?, ?, ?, ?)")) {
            stmt.setInt(1, bookId);
            stmt.setInt(2, memberId);
            stmt.setDate(3, new java.sql.Date(issueDate.getTime()));
            stmt.setDate(4, new java.sql.Date(dueDate.getTime()));
            stmt.executeUpdate();
        }

        // 4. Update book status
        try (PreparedStatement stmt = conn.prepareStatement(
                "UPDATE books SET status = 'Checked Out' WHERE id = ?")) {
            stmt.setInt(1, bookId);
            stmt.executeUpdate();
        }

        conn.commit();
        
        // Success
        JOptionPane.showMessageDialog(this, 
            "Book issued successfully!", 
            "Success", JOptionPane.INFORMATION_MESSAGE);
            
        // Reset form
        bookIdField.setText("");
        memberIdField.setText("");
        dueDateField.setText(new SimpleDateFormat("yyyy-MM-dd")
            .format(Date.from(Instant.now().plus(14, ChronoUnit.DAYS))));

    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this, 
            "Invalid ID format - must be numbers", 
            "Input Error", JOptionPane.ERROR_MESSAGE);
        try { if (conn != null) conn.rollback(); } catch (SQLException ignored) {}
    } catch (ParseException ex) {
        JOptionPane.showMessageDialog(this, 
            "Invalid date format (use YYYY-MM-DD)", 
            "Date Error", JOptionPane.ERROR_MESSAGE);
        try { if (conn != null) conn.rollback(); } catch (SQLException ignored) {}
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, 
            "Database error: " + ex.getMessage(), 
            "Error", JOptionPane.ERROR_MESSAGE);
        try { if (conn != null) conn.rollback(); } catch (SQLException ignored) {}
    } finally {
        try { 
            if (conn != null) {
                conn.setAutoCommit(true); 
                conn.close(); 
            }
        } catch (SQLException ignored) {}
    }
});

    contentPanel.add(issuePanel, BorderLayout.CENTER);
    contentPanel.revalidate();
    contentPanel.repaint();
}



   private void showReturnBook() {
    contentPanel.removeAll();
    contentPanel.setLayout(new BorderLayout());
    
    // Create return book panel
    JPanel returnPanel = new JPanel(new GridBagLayout());
    returnPanel.setBackground(new Color(245, 248, 250));
    returnPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
    
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(15, 15, 15, 15);
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.weightx = 1.0;
    
    // Title
    JLabel titleLabel = new JLabel("Return Book");
    titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
    titleLabel.setForeground(new Color(44, 62, 80));
    titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 2;
    returnPanel.add(titleLabel, gbc);
    
    // Book ID
    JLabel bookIdLabel = new JLabel("Book ID:");
    bookIdLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    gbc.gridy = 1;
    gbc.gridwidth = 1;
    returnPanel.add(bookIdLabel, gbc);
    
    JTextField bookIdField = new JTextField();
    styleTextField(bookIdField);
    gbc.gridx = 1;
    returnPanel.add(bookIdField, gbc);
    
    // Return Date
    JLabel returnDateLabel = new JLabel("Return Date:");
    returnDateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    gbc.gridx = 0;
    gbc.gridy = 2;
    returnPanel.add(returnDateLabel, gbc);
    
    JTextField returnDateField = new JTextField(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
    styleTextField(returnDateField);
    returnDateField.setEditable(false);
    gbc.gridx = 1;
    returnPanel.add(returnDateField, gbc);
    
    // Lookup Button
    JButton lookupButton = createProfessionalButton("Lookup Checkout", new Color(108, 117, 125));
    lookupButton.setPreferredSize(new Dimension(180, 35));
    gbc.gridx = 0;
    gbc.gridy = 3;
    gbc.gridwidth = 2;
    returnPanel.add(lookupButton, gbc);
    
    // Info Panel (for displaying checkout details)
    JPanel infoPanel = new JPanel(new GridLayout(0, 1, 5, 5));
    infoPanel.setBorder(BorderFactory.createTitledBorder("Checkout Information"));
    infoPanel.setBackground(new Color(245, 248, 250));
    gbc.gridy = 4;
    returnPanel.add(infoPanel, gbc);
    
    // Fine Panel (will be populated when needed)
    JPanel finePanel = new JPanel(new GridLayout(0, 1, 5, 5));
    finePanel.setBorder(BorderFactory.createTitledBorder("Fine Information"));
    finePanel.setBackground(new Color(245, 248, 250));
    finePanel.setVisible(false);
    gbc.gridy = 5;
    returnPanel.add(finePanel, gbc);
    
    // Return Button
    JButton returnButton = createProfessionalButton("Return Book", new Color(52, 152, 219));
    returnButton.setPreferredSize(new Dimension(180, 40));
    returnButton.setEnabled(false);
    gbc.gridy = 6;
    returnPanel.add(returnButton, gbc);
    
    // Store checkout ID and book ID for later use
    final int[] currentCheckoutId = {-1};
    final int[] currentBookId = {-1};
    final double[] calculatedFine = {0.0};
    final JCheckBox[] payNowCheckboxHolder = new JCheckBox[1];
    
    // Lookup Button functionality
    lookupButton.addActionListener(e -> {
        String bookIdStr = bookIdField.getText().trim();
        if (bookIdStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please enter a Book ID", 
                "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            int bookId = Integer.parseInt(bookIdStr);
            currentBookId[0] = bookId;
            
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(
                     "SELECT c.id, c.checkout_date, c.due_date, " +
                     "b.title, m.name " +
                     "FROM checkouts c " +
                     "JOIN books b ON c.book_id = b.id " +
                     "JOIN members m ON c.member_id = m.id " +
                     "WHERE c.book_id = ? AND c.returned = false")) {
                
                stmt.setInt(1, bookId);
                
                try (ResultSet rs = stmt.executeQuery()) {
                    infoPanel.removeAll();
                    finePanel.removeAll();
                    returnButton.setEnabled(false);
                    
                    if (rs.next()) {
                        currentCheckoutId[0] = rs.getInt("id");
                        
                        // Display checkout information
                        infoPanel.add(new JLabel("Book: " + rs.getString("title")));
                        infoPanel.add(new JLabel("Member: " + rs.getString("name")));
                        infoPanel.add(new JLabel("Checkout Date: " + rs.getDate("checkout_date")));
                        infoPanel.add(new JLabel("Due Date: " + rs.getDate("due_date")));
                        
                        // Calculate days overdue and fine
                        Date dueDate = rs.getDate("due_date");
                        Date returnDate = new SimpleDateFormat("yyyy-MM-dd").parse(returnDateField.getText());
                        long daysOverdue = (returnDate.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24);
                        
                        if (daysOverdue > 0) {
                            // Calculate fine: $10 base + $10 every 5 days
                            double fine = 10.0 + (10.0 * Math.floor((daysOverdue - 1) / 5));
                            calculatedFine[0] = fine;
                            
                            finePanel.add(new JLabel("Days Overdue: " + daysOverdue));
                            finePanel.add(new JLabel("Calculated Fine: $" + String.format("%.2f", fine)));
                            
                            // Add payment option
                            JCheckBox payNowCheckbox = new JCheckBox("Pay fine now");
                            payNowCheckbox.setSelected(true);
                            payNowCheckboxHolder[0] = payNowCheckbox;
                            finePanel.add(payNowCheckbox);
                            finePanel.setVisible(true);
                        } else {
                            calculatedFine[0] = 0.0;
                            finePanel.setVisible(false);
                        }
                        
                        returnButton.setEnabled(true);
                    } else {
                        JOptionPane.showMessageDialog(this, 
                            "No active checkout found for this book", 
                            "Not Found", JOptionPane.WARNING_MESSAGE);
                    }
                }
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, 
                "Please enter a valid numeric Book ID", 
                "Input Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                "Database error: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(this,
                "Invalid return date format (use YYYY-MM-DD)",
                "Date Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            infoPanel.revalidate();
            infoPanel.repaint();
            finePanel.revalidate();
            finePanel.repaint();
        }
    });
    
    // Return Button functionality
    returnButton.addActionListener(e -> {
        if (currentCheckoutId[0] == -1) {
            JOptionPane.showMessageDialog(this,
                "Please lookup a valid checkout first",
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);
            
            // 1. Update checkout record
            try (PreparedStatement stmt = conn.prepareStatement(
                "UPDATE checkouts SET returned = true, return_date = ? WHERE id = ?")) {
                
                stmt.setString(1, returnDateField.getText());
                stmt.setInt(2, currentCheckoutId[0]);
                stmt.executeUpdate();
            }
            
            // 2. Update book status to Available
            try (PreparedStatement stmt = conn.prepareStatement(
                "UPDATE books SET status = 'Available' WHERE id = ?")) {
                
                stmt.setInt(1, currentBookId[0]);
                stmt.executeUpdate();
            }
            
            // 3. If there's a fine, record it
            if (calculatedFine[0] > 0) {
                boolean payNow = payNowCheckboxHolder[0] != null && payNowCheckboxHolder[0].isSelected();
                
                try (PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO fines (checkout_id, amount, paid, payment_date) " +
                    "VALUES (?, ?, ?, ?)")) {
                    
                    stmt.setInt(1, currentCheckoutId[0]);
                    stmt.setDouble(2, calculatedFine[0]);
                    stmt.setBoolean(3, payNow);
                    stmt.setString(4, payNow ? returnDateField.getText() : null);
                    stmt.executeUpdate();
                }
            }
            
            conn.commit();
            
            // Show success message
            String message = "Book returned successfully!";
            if (calculatedFine[0] > 0) {
                message += "\nFine amount: $" + String.format("%.2f", calculatedFine[0]);
                if (payNowCheckboxHolder[0] != null && payNowCheckboxHolder[0].isSelected()) {
                    message += " (paid)";
                } else {
                    message += " (will be billed)";
                }
            }
            JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
            
            // Reset form
            bookIdField.setText("");
            infoPanel.removeAll();
            finePanel.removeAll();
            finePanel.setVisible(false);
            returnButton.setEnabled(false);
            currentCheckoutId[0] = -1;
            currentBookId[0] = -1;
            calculatedFine[0] = 0.0;
            
            // Notify listeners
            LibraryEventManager.notifyDataChanged();
        } catch (SQLException ex) {
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex1) {
                ex1.printStackTrace();
            }
            JOptionPane.showMessageDialog(this,
                "Database error: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    });
    
    contentPanel.add(returnPanel, BorderLayout.CENTER);
    contentPanel.revalidate();
    contentPanel.repaint();
}


   private void showMemberRecords() {
    contentPanel.removeAll();
    contentPanel.setLayout(new BorderLayout());
    
    // Create member records panel
    JPanel memberPanel = new JPanel(new BorderLayout());
    memberPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
    
    // Search Panel
    JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
    searchPanel.setBackground(new Color(245, 248, 250));
    searchPanel.setBorder(BorderFactory.createTitledBorder("Search Members"));
    
    JTextField searchField = new JTextField(25);
    styleTextField(searchField);
    
    JButton searchButton = createProfessionalButton("Search", new Color(52, 152, 219));
    JButton clearButton = createProfessionalButton("Clear", new Color(108, 117, 125));
    JButton addButton = createProfessionalButton("Add Member", new Color(40, 180, 99));
    
    searchButton.setPreferredSize(new Dimension(130, 30));
    clearButton.setPreferredSize(new Dimension(130, 30));
    addButton.setPreferredSize(new Dimension(150, 30));
    
    searchPanel.add(new JLabel("Search:"));
    searchPanel.add(searchField);
    searchPanel.add(searchButton);
    searchPanel.add(clearButton);
    searchPanel.add(addButton);
    
    // Members Table
    DefaultTableModel tableModel = new DefaultTableModel(
        new Object[]{"ID", "Name", "Email", "Phone", "Join Date", "Status", "Books Borrowed"}, 0) {
        @Override
        public Class<?> getColumnClass(int columnIndex) {
            if (columnIndex == 0 || columnIndex == 6) return Integer.class;
            if (columnIndex == 4) return Date.class;
            return String.class;
        }

        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    
    JTable membersTable = new JTable(tableModel);
    styleMembersTable(membersTable);
    
    JScrollPane scrollPane = new JScrollPane(membersTable);
    scrollPane.setBorder(BorderFactory.createTitledBorder("Member Records"));
    
    // Action Buttons
    JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
    actionPanel.setBackground(new Color(245, 248, 250));
    
    JButton editButton = createProfessionalButton("Edit Member", new Color(241, 196, 15));
    JButton toggleStatusButton = createProfessionalButton("Toggle Status", new Color(155, 89, 182));
    JButton deleteButton = createProfessionalButton("Delete Member", new Color(231, 76, 60));
    JButton refreshButton = createProfessionalButton("Refresh", new Color(52, 152, 219));
    
    editButton.setPreferredSize(new Dimension(150, 35));
    toggleStatusButton.setPreferredSize(new Dimension(170, 35));
    deleteButton.setPreferredSize(new Dimension(150, 35));
    refreshButton.setPreferredSize(new Dimension(130, 35));
    
    actionPanel.add(refreshButton);
    actionPanel.add(editButton);
    actionPanel.add(toggleStatusButton);
    actionPanel.add(deleteButton);
    
    // Load initial data
    Runnable loadMembers = () -> {
        tableModel.setRowCount(0); // Clear existing rows
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "SELECT m.*, COUNT(c.id) AS books_borrowed " +
                 "FROM members m LEFT JOIN checkouts c ON m.id = c.member_id AND c.returned = false " +
                 "GROUP BY m.id")) {
            
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("phone"),
                    rs.getDate("join_date"),
                    rs.getBoolean("active") ? "Active" : "Inactive",
                    rs.getInt("books_borrowed")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error loading members: " + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    };
    
    loadMembers.run();
    
    // Add Components
    memberPanel.add(searchPanel, BorderLayout.NORTH);
    memberPanel.add(scrollPane, BorderLayout.CENTER);
    memberPanel.add(actionPanel, BorderLayout.SOUTH);
    contentPanel.add(memberPanel, BorderLayout.CENTER);
    
    // ===== Event Listeners =====
    
    // Search functionality
    searchButton.addActionListener(e -> {
        String searchTerm = searchField.getText().trim();
        if (searchTerm.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a search term", "Search", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        tableModel.setRowCount(0);
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "SELECT m.*, COUNT(c.id) AS books_borrowed " +
                 "FROM members m LEFT JOIN checkouts c ON m.id = c.member_id AND c.returned = false " +
                 "WHERE m.name LIKE ? OR m.email LIKE ? OR m.phone LIKE ? " +
                 "GROUP BY m.id")) {
            
            stmt.setString(1, "%" + searchTerm + "%");
            stmt.setString(2, "%" + searchTerm + "%");
            stmt.setString(3, "%" + searchTerm + "%");
            
            ResultSet rs = stmt.executeQuery();
            int count = 0;
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("phone"),
                    rs.getDate("join_date"),
                    rs.getBoolean("active") ? "Active" : "Inactive",
                    rs.getInt("books_borrowed")
                });
                count++;
            }
            
            if (count == 0) {
                JOptionPane.showMessageDialog(this, 
                    "No members found matching '" + searchTerm + "'", 
                    "Search Results", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                "Search failed: " + ex.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    });
    
    // Clear search
    clearButton.addActionListener(e -> {
        searchField.setText("");
        loadMembers.run();
    });
    
    // Add new member
    addButton.addActionListener(e -> showAddMemberDialog(loadMembers));
    
    // Edit member
    editButton.addActionListener(e -> {
        int selectedRow = membersTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, 
                "Please select a member to edit", 
                "Edit Member", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int memberId = (Integer) tableModel.getValueAt(selectedRow, 0);
        String currentName = (String) tableModel.getValueAt(selectedRow, 1);
        String currentEmail = (String) tableModel.getValueAt(selectedRow, 2);
        String currentPhone = (String) tableModel.getValueAt(selectedRow, 3);
        boolean isActive = ((String)tableModel.getValueAt(selectedRow, 5)).equals("Active");
        
        showEditMemberDialog(memberId, currentName, currentEmail, currentPhone, isActive, loadMembers);
    });
    
    // Toggle member status
    toggleStatusButton.addActionListener(e -> {
        int selectedRow = membersTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, 
                "Please select a member", 
                "Toggle Status", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int memberId = (Integer) tableModel.getValueAt(selectedRow, 0);
        String currentStatus = (String) tableModel.getValueAt(selectedRow, 5);
        int booksBorrowed = (Integer) tableModel.getValueAt(selectedRow, 6);
        
        if (currentStatus.equals("Active") && booksBorrowed > 0) {
            JOptionPane.showMessageDialog(this, 
                "Cannot deactivate member with borrowed books", 
                "Toggle Status", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to toggle this member's status?", 
            "Confirm Status Change", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(
                     "UPDATE members SET active = NOT active WHERE id = ?")) {
                
                stmt.setInt(1, memberId);
                int affectedRows = stmt.executeUpdate();
                
                if (affectedRows > 0) {
                    loadMembers.run();
                    JOptionPane.showMessageDialog(this, 
                        "Member status updated successfully", 
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this,
                    "Error updating member status: " + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    });
    
    // Delete member
    deleteButton.addActionListener(e -> {
        int selectedRow = membersTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, 
                "Please select a member to delete", 
                "Delete Member", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int memberId = (Integer) tableModel.getValueAt(selectedRow, 0);
        String memberName = (String) tableModel.getValueAt(selectedRow, 1);
        int booksBorrowed = (Integer) tableModel.getValueAt(selectedRow, 6);
        
        if (booksBorrowed > 0) {
            JOptionPane.showMessageDialog(this, 
                "Cannot delete member with borrowed books", 
                "Delete Member", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "This will delete the member and all their checkout history. Continue?", 
            "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            Connection conn = null;
            try {
                conn = DatabaseConnection.getConnection();
                conn.setAutoCommit(false);
                
                // 1. Delete related fines first (if exists)
                try (PreparedStatement stmt = conn.prepareStatement(
                        "DELETE f FROM fines f " +
                        "JOIN checkouts c ON f.checkout_id = c.id " +
                        "WHERE c.member_id = ?")) {
                    stmt.setInt(1, memberId);
                    stmt.executeUpdate();
                }
                
                // 2. Delete checkouts
                try (PreparedStatement stmt = conn.prepareStatement(
                        "DELETE FROM checkouts WHERE member_id = ?")) {
                    stmt.setInt(1, memberId);
                    stmt.executeUpdate();
                }
                
                // 3. Delete member
                try (PreparedStatement stmt = conn.prepareStatement(
                        "DELETE FROM members WHERE id = ?")) {
                    stmt.setInt(1, memberId);
                    int affectedRows = stmt.executeUpdate();
                    
                    if (affectedRows > 0) {
                        conn.commit();
                        loadMembers.run();
                        JOptionPane.showMessageDialog(this, 
                            "Member and all related records deleted successfully", 
                            "Success", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            } catch (SQLException ex) {
                try {
                    if (conn != null) conn.rollback();
                } catch (SQLException b) {}
                JOptionPane.showMessageDialog(this,
                    "Error deleting member: " + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                try {
                    if (conn != null) conn.close();
                } catch (SQLException c) {}
            }
        }
    });
    
    // Refresh list
    refreshButton.addActionListener(e -> {
        loadMembers.run();
        JOptionPane.showMessageDialog(this, 
            "Member list refreshed", 
            "Refresh", JOptionPane.INFORMATION_MESSAGE);
    });
    
    contentPanel.revalidate();
    contentPanel.repaint();
}

private void styleMembersTable(JTable table) {
    table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
    table.getTableHeader().setBackground(new Color(233, 236, 239));
    table.setRowHeight(30);
    table.setShowGrid(true);
    table.setGridColor(new Color(222, 226, 230));
    table.setSelectionBackground(new Color(0, 123, 255, 50));
    table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    
    // Center align ID and Books Borrowed columns
    DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
    centerRenderer.setHorizontalAlignment(JLabel.CENTER);
    table.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
    table.getColumnModel().getColumn(6).setCellRenderer(centerRenderer);
    }

    private void showAddMemberDialog(Runnable refreshCallback) {
    JDialog addDialog = new JDialog(this, "Add New Member", true);
    addDialog.setSize(500, 500);
    addDialog.setLocationRelativeTo(this);
    addDialog.setLayout(new BorderLayout());
    
    JPanel formPanel = new JPanel(new GridLayout(7, 2, 15, 15));
    formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
    
    // Form fields
    JTextField nameField = new JTextField();
    JTextField emailField = new JTextField();
    JTextField phoneField = new JTextField();
    JTextField addressField = new JTextField();
    JTextField joinDateField = new JTextField(new java.text.SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date()));
    joinDateField.setEditable(false);
    JComboBox<String> statusCombo = new JComboBox<>(new String[]{"Active", "Inactive"});
    
    // Add components to form
    formPanel.add(new JLabel("Full Name:"));
    formPanel.add(nameField);
    formPanel.add(new JLabel("Email:"));
    formPanel.add(emailField);
    formPanel.add(new JLabel("Phone:"));
    formPanel.add(phoneField);
    formPanel.add(new JLabel("Address:"));
    formPanel.add(addressField);
    formPanel.add(new JLabel("Join Date:"));
    formPanel.add(joinDateField);
    formPanel.add(new JLabel("Status:"));
    formPanel.add(statusCombo);
    
    // Action buttons
    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    JButton saveButton = createProfessionalButton("Save", new Color(40, 180, 99));
    JButton cancelButton = createProfessionalButton("Cancel", new Color(231, 76, 60));
    
    buttonPanel.add(cancelButton);
    buttonPanel.add(saveButton);
    
    // Add components to dialog
    addDialog.add(formPanel, BorderLayout.CENTER);
    addDialog.add(buttonPanel, BorderLayout.SOUTH);
    
    // Event listeners
    saveButton.addActionListener(e -> {
        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        String address = addressField.getText().trim();
        boolean active = statusCombo.getSelectedItem().equals("Active");
        
        if (name.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(addDialog, 
                "Name and Email are required fields", 
                "Missing Information", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (!email.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
            JOptionPane.showMessageDialog(addDialog, 
                "Please enter a valid email address", 
                "Invalid Email", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "INSERT INTO members (name, email, phone, address, active, join_date) " +
                 "VALUES (?, ?, ?, ?, ?, ?)")) {
            
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, phone.isEmpty() ? null : phone);
            stmt.setString(4, address.isEmpty() ? null : address);
            stmt.setBoolean(5, active);
            stmt.setString(6, joinDateField.getText());
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(addDialog, 
                    "Member added successfully", 
                    "Success", JOptionPane.INFORMATION_MESSAGE);
                refreshCallback.run();
                addDialog.dispose();
            }
        } catch (SQLException ex) {
            if (ex.getMessage().contains("Duplicate entry")) {
                JOptionPane.showMessageDialog(addDialog, 
                    "A member with this email already exists", 
                    "Duplicate Email", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(addDialog,
                    "Error saving member: " + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    });
    
    cancelButton.addActionListener(e -> addDialog.dispose());
    addDialog.setVisible(true);
}

private void showEditMemberDialog(int memberId, String currentName, String currentEmail, 
                                String currentPhone, boolean isActive, Runnable refreshCallback) {
    JDialog editDialog = new JDialog(this, "Edit Member", true);
    editDialog.setSize(500, 400);
    editDialog.setLocationRelativeTo(this);
    editDialog.setLayout(new BorderLayout());
    
    JPanel formPanel = new JPanel(new GridLayout(5, 2, 15, 15));
    formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
    
    // Form fields with current values
    JTextField nameField = new JTextField(currentName);
    JTextField emailField = new JTextField(currentEmail);
    JTextField phoneField = new JTextField(currentPhone != null ? currentPhone : "");
    JComboBox<String> statusCombo = new JComboBox<>(new String[]{"Active", "Inactive"});
    statusCombo.setSelectedItem(isActive ? "Active" : "Inactive");
    
    // Add components to form
    formPanel.add(new JLabel("Full Name:"));
    formPanel.add(nameField);
    formPanel.add(new JLabel("Email:"));
    formPanel.add(emailField);
    formPanel.add(new JLabel("Phone:"));
    formPanel.add(phoneField);
    formPanel.add(new JLabel("Status:"));
    formPanel.add(statusCombo);
    
    // Action buttons
    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    JButton saveButton = createProfessionalButton("Save Changes", new Color(40, 180, 99));
    JButton cancelButton = createProfessionalButton("Cancel", new Color(231, 76, 60));
    
    buttonPanel.add(cancelButton);
    buttonPanel.add(saveButton);
    
    // Add components to dialog
    editDialog.add(formPanel, BorderLayout.CENTER);
    editDialog.add(buttonPanel, BorderLayout.SOUTH);
    
    // Event listeners
    saveButton.addActionListener(e -> {
        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        boolean active = statusCombo.getSelectedItem().equals("Active");
        
        if (name.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(editDialog, 
                "Name and Email are required fields", 
                "Missing Information", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (!email.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
            JOptionPane.showMessageDialog(editDialog, 
                "Please enter a valid email address", 
                "Invalid Email", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "UPDATE members SET name = ?, email = ?, phone = ?, active = ? WHERE id = ?")) {
            
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, phone.isEmpty() ? null : phone);
            stmt.setBoolean(4, active);
            stmt.setInt(5, memberId);
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(editDialog, 
                    "Member updated successfully", 
                    "Success", JOptionPane.INFORMATION_MESSAGE);
                refreshCallback.run();
                editDialog.dispose();
            }
        } catch (SQLException ex) {
            if (ex.getMessage().contains("Duplicate entry")) {
                JOptionPane.showMessageDialog(editDialog, 
                    "A member with this email already exists", 
                    "Duplicate Email", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(editDialog,
                    "Error updating member: " + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    });
    
    cancelButton.addActionListener(e -> editDialog.dispose());
    editDialog.setVisible(true);
}

   

    private void styleTextField(JTextField field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        field.setBackground(new Color(250, 250, 250));
    }
}
class DashboardStats {
    private int totalBooks;
    private int availableBooks;
    private int checkedOutBooks;
    private int overdueBooks;
    private int activeMembers;
    private int pendingReturns;

    public DashboardStats(int totalBooks, int availableBooks, int checkedOutBooks, 
                        int overdueBooks, int activeMembers, int pendingReturns) {
        this.totalBooks = totalBooks;
        this.availableBooks = availableBooks;
        this.checkedOutBooks = checkedOutBooks;
        this.overdueBooks = overdueBooks;
        this.activeMembers = activeMembers;
        this.pendingReturns = pendingReturns;
    }

    public int getValue(int index) {
        switch(index) {
            case 0: return totalBooks;
            case 1: return availableBooks;
            case 2: return checkedOutBooks;
            case 3: return overdueBooks;
            case 4: return activeMembers;
            case 5: return pendingReturns;
            default: return 0;
        }
    }
}

class LibraryEventManager {
    private static final List<LibraryEventListener> listeners = new ArrayList<>();
    
    public interface LibraryEventListener {
        void onLibraryDataChanged();
    }
    
    public static void addListener(LibraryEventListener listener) {
        listeners.add(listener);
    }
    
    public static void notifyDataChanged() {
        for (LibraryEventListener listener : listeners) {
            listener.onLibraryDataChanged();
        }
    }
}



